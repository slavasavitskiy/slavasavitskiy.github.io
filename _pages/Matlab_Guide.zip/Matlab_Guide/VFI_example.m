%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%% Example of Value Function Iteration Procedure %%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%% Slava Savitskiy, Brown U, 2017 %%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Parameter Set Up
clear;
close all;
% Here we want to numerically find value function for the problem
% V(k)=max{log(c) + beta*V(k')} s.t. c + k' = Ak^alpha, you can check it
% against the analytical solution, try plotting them on the same graph
% parameters set up

A=2;
alpha=1/3;
beta=0.98;

% Grid set up for capital
k_max=3; % maximum level of capital must be no less than steady state or maximum sustainable level
k_min=0.01;
M=1000; % number of points in your grid
for i=1:M;
k(i)=k_min + (k_max-k_min)*(i-1)/(M-1);
end
% or we can just do smth like this
step=0.005;
k=k_min:step:k_max; % as a result we have 'k' -- grid of capital values for which we estimate value function
M=length(k);

%% VFI (slow loop version)
%Utility matrix (assume log utility);
tic % start the timer
U=zeros([M,M]); % rows show capital today (k), colums capital tomorrow (k')
for i=1:M;
    for j=1:M;
        c=A*k(i)^alpha - k(j); % consumption level
        if c > 0
           U(i,j)=log(c); % moment. utility
        else U(i,j)=-10^6 ;% cases when c < 0 have utility of -inf, so that they won't picked as max
        end
    end
end

% Note that this code is extremely loopy, try to vectorize it

% VFI
V=zeros([M,M]); % data pre-allocation
v=zeros([M,1]); % we are taking zeros as initial guess
g=zeros([M,1]);
err=1;
% Here we iterate on the value function to find the fixed point of Bellman
% equation
while err > 10^(-7);
   for i=1:M;
    for j=1:M;
        V(i,j)=U(i,j)+beta*v(j,1); % v is your value function, initial guess is just a vector of zeros
    end
        [x y]=max(V(i,:)); % here we are basically maximizing over k' for each k
        v1(i,1)=x;% value function
        g(i,1)=y;% policy function (in terms of position on the grid, remember our discussion about max() function)
   end
err=norm(v1-v);
v=v1;
err; % you can unmute this to see the progress
end
toc % ends the timer

%% Quicker version (matrix version)
tic
e=ones(M,1);
C=A*(k').^alpha*e' - e*k;
C=max(C,10^(-300));
U=log(C); % utility matrix
% VFI
v=zeros(1,M);
err=1;
while err>10^(-7);
v1 = max( (U + beta*e*v)' );
err=norm(v-v1)
v=v1;
end

[v g]=max( (U + beta*e*v)' );% max last time to get policy function 'g'
k_pf=k(g);
toc
%% Theoretical Model (PS1 Problem 2)

I=alpha*beta*A;
H=alpha;
F=alpha/(1-beta*alpha);
E=(1-beta)^(-1)*(beta*F*log(I)+log(A*(1-beta*alpha)));

v_th=E+F*log(k);%theoretical value function
k_pfth=I*k.^(H);%theoretical policy function

%% Graphs

figure;
plot(k,v,k,v_th);
title('Value Function');
legend('Numerical','True',2);

figure;
plot(k,k_pf,k,k_pfth,k,k);
title('Policy Function');
legend('Numerical','True',2);
