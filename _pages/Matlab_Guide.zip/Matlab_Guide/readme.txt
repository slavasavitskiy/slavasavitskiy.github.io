This is a beginers guide to Matlab software for Macroeconomics students,
developed by Slava Savitskiy for the class of Macroeonomics II (Econ2080).

Content:
Beginers_guide.m -- is the main guide;
obj_fun.m -- file to be used with the beginers guide;
VFI_example -- practical example for Value Function Iteration (VFI) procedure.