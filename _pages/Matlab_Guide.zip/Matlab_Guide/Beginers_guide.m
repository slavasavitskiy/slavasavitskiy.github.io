%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%% Beginers Guide to Matlab for Macroeconomics students %%%%%%%%%%%%
%%%%%%%%%%%%%%%%%% Slava Savitskiy, Brown U, 2017 %%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear;
close all; % closes all open windows (graphs, figures, etc)
%% array and matrix
clear; % delets all variables
% put one '%' to make a comment, put '%%' to separate sections
N=5; % ';' makes comand silent
a=ones(N,1);
b=zeros(1,N);
A=eye(N)*2; % unit matrix
B=[1 2 3; 
   4 5 6]; % 2 by 3 matrix
C=[1 0 0; 0 0 1]; % vectors and matrices are defined using [ ], ( ) are used for function arguments
D=B*C'; % matrix product * and transposing ' 
d=size(D); % we can also use comand length( ) to see the largest dimension
B_sq=B.^2; % put dot '.' to make your function element-by-element
A_inv=inv(A); 
log_a=log(a); % some functions always work element-by-elemnt
log_a2=log_a(2); % second entree of the vector
% basic algebra functions are + - * / ^ ' log() exp() sin() etc

%% random variables
clear;
N=1000;
a=rand(N,1); % random uniform on [0;1]
figure; % put figure command to keep graph, o/w it will be rewritten
plot(a-0.5);
title('White Noise');

mu=0;
sigma=1;
b=normrnd(mu,sigma,N,1); % generating random normal variable
figure;
hist(b,15);

MU=[2 0]';
SIGMA=[1 0.8; 0.8 1];
A = mvnrnd(MU,SIGMA,N); % generating random multivar normal variable

figure;
hist3(A);

% lets generate model and estimate it with OLS

X=ones(N,3);
X(:,2)=rand(N,1);
X(:,3)=2*rand(N,1) - 1;
beta=[1 -2 4]'; % true coefficients of DGP
sigma_ep=2; % var of the error term
epsilon=normrnd(0,sigma_ep,N,1); % normal errors
Y=X*beta + epsilon;
beta_ols=inv(X'*X)*X'*Y; % formula for OLS estimate




%% loops and logic conditions
clear;
% 'for' loop
N=100;
for i=1:N
    a(i)=i^2; % highlight and right click 'eval selection'
end

% don't do it, takes too much time. Always try to vectorize your code,
% makes it faster. do like this:

a=(1:N).^2;
figure;
plot(1:N,a);

% stationary process b_t=\psi*(b_{t+1})^{\alpha}
b(1)=1;% initial condition
psi=4;
alpha=0.5;
for i=2:N;
   b(i)=psi*b(i-1)^(alpha); 
end
b(N) % steady state, should be equal to psi^(1/(1-alpha))=16;


% 'while' loop

c(1)=1;
err=1;
t=1;

while err>10^(-7); % condition under which loop runs
   t=t+1;
   c(t)=psi*c(t-1)^(alpha);
   err=norm(c(t)-c(t-1)); % difference between c_{t-1} and c_t, loop terminates than it is smaller than 10^(-6)
end

% 3n+1 problem aka The Collatz Conjecture

n=7; % initial point
t=0;
while n>1;
   t=t+1;
    if mod(n,3) == 0 % when making 'if' statement use ==, >, >=, <=, <, use && for 'and' and || for 'or'
        n=n/2;
    else n=3*n+1; % use 'elseif' to add aditional options
    
    end
end


J=1000;
for j=1:J
n=j;
t=0;
while n>1;
   t=t+1;
    if mod(n,2) == 0 % when making 'if' statement use ==, >, >=, <=, <, use && for 'and' and || for 'or'
        n=n/2;
    else n=3*n+1; % use 'elseif' to add aditional options
    end
end
It(j)=t;
end

% Markov process
Pi=[0.8 0.0 0.2; 
    0.3 0.4 0.3;
    0.2 0.2 0.6]; % transition matrix, rows must sum up to 1. Usually row shows in which state you are now, column - to which state you go

mu0=[1/3 1/3 1/3]; % initial distribution across states of MP
% we want to find the 'steady state' of the process
err=1;
while err>10^(-6)

mu1= mu0*Pi; % distribution next period
err=norm(mu1-mu0);
mu0=mu1; % reasign mu0 to keep it rolling
end

%% Normality of OLS estimates example
clear;
beta=[1 -2 4]'; % true values of betas
N=1000; % number of observations
M=5000; % number of simulations

for j=1:M;
X=ones(N,3);
X(:,2)=rand(N,1);
X(:,3)=2*rand(N,1) - 1;
epsilon=normrnd(0,3,N,1);
Y=X*beta + epsilon; % DGP
beta_ols=inv(X'*X)*X'*Y;
b2(j)=beta_ols(2);
b3(j)=beta_ols(3);
end
figure;
hist(b2,20);

%% functions and optimization
clear;
a=[1 -2 1]; % x^2 - 2x + 1
z=sqequation(a); % example of the function, open sqequation.m to see it

ex_fun = @(x) -x.^2 + 6*x + 10; % use this to define simple functions on the go
% ex_fun is now a legit function of x
x=-5:0.1:5; % creates even grid of x's from -5 to 5 at a 0.1 step
y=ex_fun(x); % I can supply vector to it, since I put .^ in the function
[y0 k0]=max(y); % finds the maximal element in the array and its position, y0 - max and k0 - argmax (position of the actual argmax on the grid)
x0=x(k0); % actual argmax (important for VFI)

x_int=0;
ex_fun2 = @(x) -ex_fun(x);% put - since command minimizes 
[x1 y1]= fminunc(ex_fun2,x_int); % finds local minimum, x_int - initial point
y1=-y1;

ex_fun3 = @(x) log(x) - 1;
x3=fsolve(ex_fun3,1); % finds zeros of the function

% initial condition matters
ex_fun4 = @(x) sin(x);
mu=0.2;
x4 = fsolve(ex_fun4,pi*mu); % try different values of mu to see different solutions

% constrained maximization (consumer's problem example)
p=[1 2]; % vector of prices
I=4; % income
A=[-1 0; 0 -1; p(1) p(2)]; 
b=[0 0 I]'; % non-equality constraints of the form A*x <= b, visit Mathworks documentation for more options (https://www.mathworks.com/help/optim/ug/fmincon.html)
alpha=0.5;
fun = @(x) -obj_fun(x,alpha); % important to asign specific parameter value before optimizing
[x_s y_s]=fmincon(fun,[10 10],A,b); % finds local minimum under constraints (more info on mathworks)
y_s=-y_s;

%% Hints on VFI
clear;
close all;
% Here we want to numerically find value function for the problem
% V(k)=max{log(c) + beta*V(k')} s.t. c + k' = Ak^alpha, you can check it
% against the analytical solution, try plotting them on the same graph
% parameters set up
A=2;
alpha=1/3;
beta=0.98;

% Grid set up for capital
k_max=5; % maximum level of capital must be no less than steady state or maximum sustainable level
k_min=0.01;
M=1000; % number of points in your grid
for i=1:M;
k(i)=k_min + (k_max-k_min)*(i-1)/(M-1);
end
% or we can just do smth like this
step=0.005;
k=k_min:step:k_max; % as a result we have 'k' -- grid of capital values for which we estimate value function
M=length(k);

% Utility matrix (assume log utility);
U=zeros([M,M]); % rows show capital today (k), colums capital tomorrow (k')
for i=1:M;
    for j=1:M;
        c=A*k(i)^alpha - k(j); % consumption level
        if c > 0
           U(i,j)=log(c); % moment. utility
        else U(i,j)=-inf ;% cases when c < 0 have utility of -inf, so that they won't picked as max
        end
    end
end

% Note that this code is extremely loopy, try to vectorize it

% VFI
V=zeros([M,M]); % data pre-allocation
v=zeros([M,1]);
g=zeros([M,1]);
err=1;
% Here we iterate on the value function to find the fixed point of Bellman
% equation
while err > 10^(-6);
   for i=1:M;
    for j=1:M;
        V(i,j)=U(i,j)+beta*v(j,1); % v is your value function, initial guess is just a vector of zeros
    end
        [x y]=max(V(i,:)); % here we are basically maximizing over k'
        v1(i,1)=x;% value function
        g(i,1)=y;% policy function (in terms of position on the grid, remember our discussion about max() function)
   end
err=norm(v1-v);
v=v1;
err; % you can unmute this to see the progress
end

figure;
plot(k,v); % plots value function (k,v) means k is x and v is y=f(x), k and v must be of the same length
% you can plot several graphs on one figure, for example plot(k,v,k,v^2)
% would give you value function and value function squared as a functions
% of k on the same plane

% how would you find policy function in terms of capital levels? plot it


