% defining a Cobb-Douglas objective function with paramtere alpha
function y=obj_fun(x,alpha);
% x is 2-by-1 vector, alpha - scalar parameter
y=x(1)^alpha * x(2)^(1-alpha);
end
